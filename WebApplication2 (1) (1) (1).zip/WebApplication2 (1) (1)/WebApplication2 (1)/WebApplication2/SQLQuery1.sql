﻿CREATE TABLE userinfo2(
						
						email VARCHAR(40) NOT NULL,
                        Password varchar(40) not null)
                        

INSERT INTO userinfo2 VALUES('Di@gmail.com','abcd')
INSERT INTO userinfo2 VALUES('Mo@gmail.com','abcd12')
INSERT INTO userinfo2 VALUES('linda@gmail.com','1234567')

drop table userinfo2;

